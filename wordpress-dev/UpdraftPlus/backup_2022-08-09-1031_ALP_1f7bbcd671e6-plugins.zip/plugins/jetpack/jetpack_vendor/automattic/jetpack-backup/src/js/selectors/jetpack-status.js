const jetpackStatusSelectors = {
	getCalypsoSlug: state => state.jetpackStatus.calypsoSlug || {},
};

export default jetpackStatusSelectors;
